"""
collect_vpt_dataset.py
-----------------------

This script collects offline training data by running a pretrained VPT policy
within a MineRL environment and recording the observations along with the
teacher's action logits and value estimates.  The resulting dataset is
serialized to a PyTorch file containing tensors for pixels, scalars, goals,
teacher logits, and teacher values.  The script defines helper functions to
convert MineRL observation dictionaries into the format expected by your
student model.

Usage:
    python -m vpt_minerl.data.collect_vpt_dataset \
        --env_id MineRLTreechop-v0 \
        --episodes 50 \
        --max_steps 1000 \
        --out_path data/vpt_teacher_dataset.pt \
        --model_path third_party/vpt/models/foundation-model-1x.model \
        --weights_path third_party/vpt/models/foundation-model-1x.weights

This will run the VPT teacher for 50 episodes in the ``MineRLTreechop-v0``
environment, collecting up to 1000 steps per episode, and save the dataset
to the specified path.  You can adjust the environment and number of
episodes/steps according to your needs.

Important:
    This script requires MineRL to be installed (e.g., via ``pip install
    minerl``).  Because MineRL downloads large assets on first use, the
    initial run may take some time.  Ensure that your network connection
    permits downloading the dataset and that you have sufficient disk space.

"""

from __future__ import annotations

import argparse
import pathlib
from typing import Dict, Any, List

import numpy as np
import torch
import torch.nn.functional as F

try:
    import minerl
except ImportError:
    raise ImportError(
        "MineRL is required to collect datasets. Install it with\n"
        "pip install git+https://github.com/minerllabs/minerl"
    )

from vpt_minerl.training.vpt_policy import VPTPolicy


def obs_to_student_format(obs: Dict[str, Any]) -> Dict[str, torch.Tensor]:
    """Convert MineRL obs dict into student tensor format.

    The student model expects three separate inputs:

    * ``pixels``: a Tensor of shape ``(3, 128, 128)`` representing an RGB
      image.  Here, we resize the ``pov`` image from the environment to
      128×128 and convert it to ``float32``.
    * ``scalars``: a Tensor of shape ``(20,)`` representing game state
      information.  Because the MineRL environments provide an observation
      dictionary with many fields, you can choose which fields to include
      here.  In this example, we compute the mean and standard deviation of
      the pixel values for each channel and pad the remaining elements with
      zeros.  You should modify this function to include meaningful
      environment-specific state features (e.g., inventory, health, or
      positions) if available.
    * ``goals``: a Tensor of shape ``(4,)`` representing high-level goals.
      Here we provide a constant goal vector [1, 0, 0, 0] indicating a
      preference to explore.  You should encode domain-specific objectives
      relevant to your tasks.

    Parameters
    ----------
    obs : dict
        Observation dictionary returned by the MineRL environment.  Must
        contain a key ``"pov"`` with pixel observations of shape
        (H, W, 3).

    Returns
    -------
    dict
        A dictionary with keys ``"pixels"``, ``"scalars"``, and
        ``"goals"`` containing the corresponding Tensors.
    """
    # Convert the pixel observation to a Torch tensor and transpose
    pov = obs["pov"]  # shape (H, W, 3), type uint8
    pov_tensor = torch.from_numpy(pov).permute(2, 0, 1).float()  # (3, H, W)

    # Resize to 128×128 using bilinear interpolation
    pov_tensor = F.interpolate(
        pov_tensor.unsqueeze(0), size=(128, 128), mode="bilinear", align_corners=False
    ).squeeze(0)

    # Normalize pixel values to [0, 255].  Downstream training code will
    # divide by 255 and optionally normalize further.
    # Compute per-channel statistics for scalars
    mean_rgb = pov_tensor.view(3, -1).mean(dim=1) / 255.0
    std_rgb = pov_tensor.view(3, -1).std(dim=1) / 255.0

    scalars = torch.zeros(20, dtype=torch.float32)
    scalars[0:3] = mean_rgb
    scalars[3:6] = std_rgb

    # Constant goals (modify as needed)
    goals = torch.tensor([1.0, 0.0, 0.0, 0.0], dtype=torch.float32)

    return {"pixels": pov_tensor, "scalars": scalars, "goals": goals}


def collect_dataset(
    env_id: str,
    episodes: int,
    max_steps: int,
    out_path: str,
    model_path: str,
    weights_path: str,
) -> None:
    """Collect offline data by rolling out a VPT policy in a MineRL environment.

    Parameters
    ----------
    env_id : str
        Name of the MineRL environment to use (e.g., ``"MineRLTreechop-v0"``).
    episodes : int
        Number of episodes to collect.
    max_steps : int
        Maximum number of steps per episode.  If an episode terminates
        earlier (``done`` is True), collection will proceed to the next
        episode.
    out_path : str
        Destination file path for the collected dataset (e.g., ``"data/vpt_teacher_dataset.pt"``).
    model_path : str
        Relative path to the VPT model architecture file (.model).
    weights_path : str
        Relative path to the VPT model weights file (.weights).
    """
    device = "cuda" if torch.cuda.is_available() else "cpu"

    # Initialize environment
    env = minerl.make(env_id)

    # Instantiate teacher policy
    policy = VPTPolicy(
        model_path=model_path,
        weights_path=weights_path,
        device=device,
    )

    # Prepare storage lists
    pixels_list: List[torch.Tensor] = []
    scalars_list: List[torch.Tensor] = []
    goals_list: List[torch.Tensor] = []
    logits_list: List[torch.Tensor] = []
    value_list: List[torch.Tensor] = []

    for ep in range(episodes):
        obs = env.reset()
        done = False
        step = 0
        ep_reward = 0.0

        while not done and step < max_steps:
            # Convert environment observation to student format
            formatted = obs_to_student_format(obs)
            pixels = formatted["pixels"]
            scalars = formatted["scalars"]
            goals = formatted["goals"]

            # Query the teacher policy
            logits, value = policy(obs)

            # Record data
            pixels_list.append(pixels.cpu())
            scalars_list.append(scalars.cpu())
            goals_list.append(goals.cpu())
            logits_list.append(logits.detach().cpu())
            value_list.append(value.detach().cpu())

            # Sample action from teacher distribution
            probs = torch.softmax(logits, dim=-1).cpu().numpy()
            # Choose an action index based on the policy's distribution
            action_idx = int(np.random.choice(len(probs), p=probs))

            # Retrieve the environment action corresponding to the discrete index
            # NOTE: ``policy.agent.get_action`` returns the action chosen by the
            # policy given an observation.  Here, we simply call it again to
            # obtain the action dictionary or index.  This may be inefficient,
            # but suffices for offline collection.  If the action is a
            # dictionary, env.step will accept it directly.  If it is an
            # integer, the environment must provide a discrete action space.
            action = policy.agent.get_action(obs)  # type: ignore

            obs, reward, done, info = env.step(action)
            ep_reward += reward
            step += 1

        print(f"[collect] Episode {ep+1}/{episodes} finished with reward {ep_reward:.2f} after {step} steps")

    # Stack and save tensors
    data_dict = {
        "pixels": torch.stack(pixels_list, dim=0),
        "scalars": torch.stack(scalars_list, dim=0),
        "goals": torch.stack(goals_list, dim=0),
        "teacher_logits": torch.stack(logits_list, dim=0),
        "teacher_value": torch.stack(value_list, dim=0),
    }

    out_path = pathlib.Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    torch.save(data_dict, out_path)
    print(f"Saved dataset with {len(pixels_list)} samples to {out_path}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Collect offline data from VPT teacher")
    parser.add_argument("--env_id", type=str, default="MineRLTreechop-v0", help="MineRL environment ID")
    parser.add_argument("--episodes", type=int, default=10, help="Number of episodes to collect")
    parser.add_argument("--max_steps", type=int, default=1000, help="Maximum steps per episode")
    parser.add_argument("--out_path", type=str, default="data/vpt_teacher_dataset.pt", help="Output path for dataset")
    parser.add_argument("--model_path", type=str, default="third_party/vpt/models/foundation-model-1x.model", help="Path to VPT model file")
    parser.add_argument("--weights_path", type=str, default="third_party/vpt/models/foundation-model-1x.weights", help="Path to VPT weights file")
    args = parser.parse_args()

    collect_dataset(
        env_id=args.env_id,
        episodes=args.episodes,
        max_steps=args.max_steps,
        out_path=args.out_path,
        model_path=args.model_path,
        weights_path=args.weights_path,
    )


if __name__ == "__main__":
    main()