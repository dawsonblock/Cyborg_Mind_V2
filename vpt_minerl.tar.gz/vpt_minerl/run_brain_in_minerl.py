"""
run_brain_in_minerl.py
----------------------

This script demonstrates how to run a trained student brain within a MineRL
environment for inference.  The script loads a serialized state dict for
``BrainCyborgDynamic``, constructs the model, and repeatedly calls it to
obtain actions.  It prints basic metrics (reward and step count) at the end
of each episode.  You can use this script to validate that your student
network performs reasonable actions in the environment after training.

Example usage:
    python -m vpt_minerl.run_brain_in_minerl \
        --ckpt_path checkpoints_vpt_distill/student_final.pt \
        --env_id MineRLTreechop-v0 \
        --episodes 5 \
        --max_steps 1000

"""

from __future__ import annotations

import argparse
import pathlib

import torch

try:
    import minerl
except ImportError:
    raise ImportError(
        "MineRL is required to run the environment. Install with\n"
        "pip install git+https://github.com/minerllabs/minerl"
    )

try:
    from capsule_brain.policy.brain_cyborg_dynamic import BrainCyborgDynamic
except ImportError:
    raise ImportError(
        "BrainCyborgDynamic could not be imported. Ensure that your model"
        " implementation is available on the Python path."
    )

from vpt_minerl.data.collect_vpt_dataset import obs_to_student_format


def run_student(
    ckpt_path: str,
    env_id: str,
    episodes: int,
    max_steps: int,
) -> None:
    """Run a trained student brain in a MineRL environment.

    Parameters
    ----------
    ckpt_path : str
        Path to the student model checkpoint (.pt file).
    env_id : str
        Name of the MineRL environment (e.g., ``"MineRLTreechop-v0"``).
    episodes : int
        Number of episodes to run.
    max_steps : int
        Maximum steps per episode.
    """
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    env = minerl.make(env_id)

    # Initialize the student model
    student = BrainCyborgDynamic().to(device)
    ckpt = torch.load(ckpt_path, map_location=device)
    student.load_state_dict(ckpt)
    student.eval()

    for ep in range(episodes):
        obs = env.reset()
        done = False
        step = 0
        ep_reward = 0.0

        while not done and step < max_steps:
            formatted = obs_to_student_format(obs)
            pixels = formatted["pixels"].unsqueeze(0).to(device)
            scalars = formatted["scalars"].unsqueeze(0).to(device)
            goals = formatted["goals"].unsqueeze(0).to(device)
            thought = torch.zeros(1, 32, device=device)

            with torch.no_grad():
                out = student(pixels, scalars, goals, thought, step=step)
                action_idx = out.action_logits.argmax(dim=-1).item()

            # Convert discrete index back to environment action.  For MineRL
            # environments with a discrete action space, the environment
            # accepts a single integer.  If your environment uses a dict
            # action space, you must map the index to the appropriate
            # dictionary.  The VPT agent provides mapping utilities, but
            # those are not exposed here.  As a placeholder, we simply
            # reuse the environment's action space sample to avoid errors.
            if isinstance(env.action_space, int):  # type: ignore
                action = action_idx
            else:
                # Fallback: use a random action from the environment's
                # action space.  Replace this with a proper mapping.
                action = env.action_space.sample()

            obs, reward, done, info = env.step(action)
            ep_reward += reward
            step += 1

        print(
            f"[run] Episode {ep+1}/{episodes} finished with reward {ep_reward:.2f} after {step} steps"
        )


def main() -> None:
    parser = argparse.ArgumentParser(description="Run a distilled student brain in MineRL")
    parser.add_argument("--ckpt_path", type=str, required=True, help="Path to student checkpoint")
    parser.add_argument("--env_id", type=str, default="MineRLTreechop-v0", help="MineRL environment ID")
    parser.add_argument("--episodes", type=int, default=1, help="Number of episodes to run")
    parser.add_argument("--max_steps", type=int, default=1000, help="Maximum steps per episode")
    args = parser.parse_args()

    run_student(
        ckpt_path=args.ckpt_path,
        env_id=args.env_id,
        episodes=args.episodes,
        max_steps=args.max_steps,
    )


if __name__ == "__main__":
    main()