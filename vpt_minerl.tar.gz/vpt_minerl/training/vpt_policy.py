"""
vpt_policy.py
----------------

This module defines a wrapper around OpenAI's Video Pre-Training (VPT) policy for
use as a teacher in offline distillation.  The `VPTPolicy` class loads a
pretrained MineRLAgent from the VPT repository and exposes a simple API that
accepts a MineRL observation dictionary and returns a tuple of action logits
and a value estimate.  The logits are returned as a dense tensor where the
index of the highest logit corresponds to the discrete action chosen by the
VPT policy.  A lightweight learned critic (`value_head`) is included as a
fallback for providing value estimates when the underlying VPT policy does
not expose a value head.

To integrate this wrapper with your own environment, you should inspect the
`agent.py` implementation in the VPT repository to determine whether the
policy exposes pre-softmax logits and a value function.  If such methods are
available, you can replace the one-hot logits construction and value head
with calls to those methods.

Usage:
    policy = VPTPolicy(
        model_path="third_party/vpt/models/foundation-model-1x.model",
        weights_path="third_party/vpt/models/foundation-model-1x.weights",
        device="cuda",
    )
    obs = env.reset()
    logits, value = policy(obs)

"""

from __future__ import annotations

import os
import sys
import pathlib
from typing import Dict, Tuple

import torch
import torch.nn as nn

# Add the VPT repository to the Python path.  Adjust this path according to
# your project structure.  The wrapper expects the VPT repo to be located
# at ``third_party/vpt`` relative to the project root.
ROOT = pathlib.Path(__file__).resolve().parents[2]
VPT_ROOT = ROOT / "third_party" / "vpt"
if VPT_ROOT.exists():
    sys.path.append(str(VPT_ROOT))
else:
    # We do not raise an error here because this file may be imported in
    # environments where the VPT repository is not present.  In such cases,
    # instantiating VPTPolicy will raise a FileNotFoundError later.
    pass

try:
    # MineRLAgent provides a unified interface for loading the VPT model and
    # interacting with its policy.
    from agent import MineRLAgent  # type: ignore
except ImportError:
    # If the import fails, we define a placeholder to provide a clear
    # error message when attempting to instantiate VPTPolicy.
    MineRLAgent = None  # type: ignore


class VPTPolicy(nn.Module):
    """Wrapper around OpenAI's VPT policy to produce logits and values.

    Parameters
    ----------
    model_path : str
        Path to the VPT model architecture file (.model).
    weights_path : str
        Path to the VPT model weights file (.weights).
    device : str, optional
        PyTorch device on which to run the VPT policy.  If ``cuda`` is
        available, the policy will run on the GPU; otherwise, it will run on
        the CPU.

    Notes
    -----
    This wrapper currently constructs a one-hot logit vector for the
    teacher actions because the VPT agent API does not expose the raw
    pre-softmax logits.  You can modify the implementation to call into the
    underlying policy if you inspect the VPT repository and find a suitable
    method.
    """

    def __init__(
        self,
        model_path: str,
        weights_path: str,
        device: str = "cuda",
    ) -> None:
        super().__init__()

        # Determine device
        self.device: torch.device = torch.device(device if torch.cuda.is_available() else "cpu")

        # Construct absolute paths to the model and weights
        model_path = str(ROOT / model_path)
        weights_path = str(ROOT / weights_path)

        if not os.path.isfile(model_path):
            raise FileNotFoundError(f"VPT model file not found: {model_path}")
        if not os.path.isfile(weights_path):
            raise FileNotFoundError(f"VPT weights file not found: {weights_path}")

        if MineRLAgent is None:
            raise ImportError(
                "MineRLAgent could not be imported. Ensure that the VPT repository is"
                " available at third_party/vpt and that its dependencies are installed."
            )

        # Instantiate the VPT agent.  Passing ``env=None`` allows the agent
        # to be constructed without an active environment; it will use default
        # configurations defined in ``agent.py`` to create a policy suitable
        # for inference.
        self.agent = MineRLAgent(
            env=None,
            model_path=model_path,
            weights_path=weights_path,
            device=self.device,
        )

        # Number of discrete actions in the VPT action space
        self.num_actions: int = self.agent.action_space.n  # type: ignore

        # A simple learned critic that maps one-hot action vectors to scalar
        # value estimates.  This is a fallback in case the VPT policy does
        # not expose a value head; you can remove this and rely on the
        # policy's native value output if available.
        self.value_head = nn.Sequential(
            nn.Linear(self.num_actions, 128),
            nn.ReLU(),
            nn.Linear(128, 1),
        ).to(self.device)

    def forward(self, obs: Dict) -> Tuple[torch.Tensor, torch.Tensor]:
        """Given a MineRL observation, return teacher logits and value estimate.

        Parameters
        ----------
        obs : dict
            Observation dict from a MineRL environment.  At minimum, this
            dictionary must include the key ``"pov"`` containing the pixel
            observation (H x W x 3) expected by the VPT policy.  Additional
            fields will be passed through to the underlying policy without
            modification.

        Returns
        -------
        logits : torch.Tensor
            Tensor of shape ``(num_actions,)`` containing unnormalized
            preferences for each discrete action.  The highest value in
            ``logits`` corresponds to the action chosen by the VPT agent.

        value : torch.Tensor
            Tensor of shape ``(1,)`` containing a scalar value estimate for
            the given observation.  This is derived from the one-hot action
            using a learned critic.  If the underlying policy exposes a
            value head, you should replace this with that value.
        """
        # Put the policy into evaluation mode
        self.agent.policy.eval()  # type: ignore

        # Query the VPT agent for its action.  The return type depends on
        # the environment wrapper; typically, this will be a discrete integer
        # representing the chosen action, but some wrappers may return a
        # dictionary mapping action components.
        action = self.agent.get_action(obs)  # type: ignore

        # If the action is a dictionary, it must be converted into a discrete
        # index.  The agent provides a mapping between discrete indices and
        # action dictionaries; however, this mapping is not documented in the
        # VPT repo.  Users should inspect ``agent.py`` and modify the
        # following block accordingly.
        if isinstance(action, dict):
            raise NotImplementedError(
                "Dictionary actions are not supported in this implementation."
                " Please map action dictionaries to discrete indices using"
                " the VPT agent's action mapping functions."
            )

        # Convert discrete action to one-hot logits.  Because the VPT API
        # currently exposes only the chosen action index, we simulate a
        # policy distribution by assigning a high score (0.0) to the chosen
        # action and a very negative score (-1e9) to all others.
        action_idx = int(action)
        logits = torch.full(
            (self.num_actions,), -1e9, dtype=torch.float32, device=self.device
        )
        logits[action_idx] = 0.0

        # Create a one-hot vector for the chosen action to pass through
        # the learned critic.  You can remove this and rely on the VPT
        # policy's native value head if available.
        one_hot = torch.zeros(self.num_actions, dtype=torch.float32, device=self.device)
        one_hot[action_idx] = 1.0
        value = self.value_head(one_hot.unsqueeze(0)).squeeze(0)  # shape (1,)

        return logits, value