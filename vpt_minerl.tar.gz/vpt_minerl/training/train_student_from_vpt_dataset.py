"""
train_student_from_vpt_dataset.py
---------------------------------

This module provides a training routine to distill a VPT teacher into your
student architecture using a pre-collected offline dataset.  The dataset
should include the teacher's action logits and value estimates for each
observation.  The script defines a dataset loader class, a distillation
loss function, and a ``train_student`` function that iterates over the
offline dataset, computes the student outputs, and updates the model
parameters.

To run the training script from the command line, execute:

    python -m vpt_minerl.training.train_student_from_vpt_dataset \
        --dataset_path data/vpt_teacher_dataset.pt \
        --out_dir checkpoints_vpt_distill \
        --epochs 5 \
        --batch_size 32

This will load the dataset, split 90% for training and 10% for validation,
train the student network for the specified number of epochs, and save
checkpoints at the end of each epoch.

Note:
    You must have your student model (e.g., ``BrainCyborgDynamic``) available
    and importable for this script to work.  Adjust the import path below to
    match your project structure.

"""

from __future__ import annotations

import argparse
import pathlib
from typing import Tuple

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader, random_split

# You must adjust this import to match the actual location of your student model
try:
    from capsule_brain.policy.brain_cyborg_dynamic import BrainCyborgDynamic
except ImportError:
    # Provide a placeholder and raise a clear error if the model cannot be imported
    raise ImportError(
        "BrainCyborgDynamic could not be imported. Please ensure that the"
        " capsule_brain module is available on the Python path."
    )


class VPTDistillDataset(Dataset):
    """Dataset wrapper for the offline VPT teacher data.

    The dataset file is expected to be a PyTorch file containing the keys
    ``'pixels'``, ``'scalars'``, ``'goals'``, ``'teacher_logits'``, and
    ``'teacher_value'``.  Each key maps to a tensor where the first
    dimension corresponds to the number of samples.
    """
    def __init__(self, dataset_path: str) -> None:
        full_path = pathlib.Path(dataset_path)
        if not full_path.is_file():
            raise FileNotFoundError(f"Dataset file not found: {full_path}")
        data = torch.load(full_path, map_location="cpu")
        self.pixels = data["pixels"]  # shape (N, 3, 128, 128)
        self.scalars = data["scalars"]  # shape (N, 20)
        self.goals = data["goals"]  # shape (N, 4)
        self.teacher_logits = data["teacher_logits"]  # shape (N, A)
        self.teacher_value = data["teacher_value"]  # shape (N, 1)

    def __len__(self) -> int:
        return self.pixels.shape[0]

    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        return (
            self.pixels[idx],
            self.scalars[idx],
            self.goals[idx],
            self.teacher_logits[idx],
            self.teacher_value[idx],
        )


def distillation_loss(
    student_out,
    teacher_logits: torch.Tensor,
    teacher_value: torch.Tensor,
    temperature: float = 2.0,
    mem_reg_weight: float = 0.01,
) -> torch.Tensor:
    """Compute distillation loss between student and teacher outputs.

    The loss is composed of three components:
        1. KL divergence between the student's action logits and the teacher's
           softened distribution.
        2. Mean squared error between the student's value predictions and
           the teacher's values.
        3. L2 regularization on the student's memory write vector to
           encourage stable memory usage.

    Parameters
    ----------
    student_out : object
        The output from the student network.  Must have attributes
        ``action_logits``, ``value``, and ``mem_write``.
    teacher_logits : torch.Tensor
        Tensor of shape ``(B, A)`` containing the teacher's action logits.
    teacher_value : torch.Tensor
        Tensor of shape ``(B, 1)`` containing the teacher's value estimates.
    temperature : float, optional
        Temperature parameter for the KL divergence.  Higher values produce
        smoother target distributions.
    mem_reg_weight : float, optional
        Weighting factor for the memory regularization term.

    Returns
    -------
    torch.Tensor
        Scalar loss value.
    """
    # KL divergence on softened logits
    kl_loss = nn.functional.kl_div(
        nn.functional.log_softmax(student_out.action_logits / temperature, dim=-1),
        nn.functional.softmax(teacher_logits / temperature, dim=-1),
        reduction="batchmean",
    ) * (temperature ** 2)

    # MSE on value predictions
    value_loss = nn.functional.mse_loss(student_out.value, teacher_value)

    # Memory write regularization (if available)
    if hasattr(student_out, "mem_write") and student_out.mem_write is not None:
        mem_reg = torch.mean(torch.norm(student_out.mem_write, dim=-1))
    else:
        mem_reg = torch.tensor(0.0, device=teacher_logits.device)

    return kl_loss + 0.5 * value_loss + mem_reg_weight * mem_reg


def train_student(
    dataset_path: str,
    out_dir: str,
    batch_size: int = 64,
    epochs: int = 10,
    lr: float = 1e-4,
    weight_decay: float = 1e-5,
    log_every: int = 100,
    ckpt_every: int = 1,
) -> None:
    """Train the student model from the offline VPT distillation dataset.

    Parameters
    ----------
    dataset_path : str
        Path to the dataset file (PyTorch format) generated by the data
        collection script.
    out_dir : str
        Directory in which to save checkpoints and logs.
    batch_size : int, optional
        Number of samples per training batch.
    epochs : int, optional
        Number of training epochs.
    lr : float, optional
        Learning rate for the AdamW optimizer.
    weight_decay : float, optional
        Weight decay factor for the AdamW optimizer.
    log_every : int, optional
        Frequency (in steps) at which to print training metrics.
    ckpt_every : int, optional
        Frequency (in epochs) at which to save checkpoints.
    """
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    out_dir_path = pathlib.Path(out_dir)
    out_dir_path.mkdir(parents=True, exist_ok=True)

    # Load the dataset and split into training and validation sets
    full_dataset = VPTDistillDataset(dataset_path)
    total_samples = len(full_dataset)
    val_size = max(1, int(0.1 * total_samples))
    train_size = total_samples - val_size
    train_ds, val_ds = random_split(full_dataset, [train_size, val_size])

    train_loader = DataLoader(
        train_ds, batch_size=batch_size, shuffle=True, num_workers=4, pin_memory=True
    )
    val_loader = DataLoader(
        val_ds, batch_size=batch_size, shuffle=False, num_workers=2, pin_memory=True
    )

    # Initialize the student model
    student = BrainCyborgDynamic().to(device)
    student.train()

    optimizer = optim.AdamW(student.parameters(), lr=lr, weight_decay=weight_decay)

    global_step = 0
    for epoch in range(1, epochs + 1):
        student.train()
        for batch in train_loader:
            pixels, scalars, goals, teacher_logits, teacher_value = batch
            pixels = pixels.to(device, non_blocking=True)
            scalars = scalars.to(device, non_blocking=True)
            goals = goals.to(device, non_blocking=True)
            teacher_logits = teacher_logits.to(device, non_blocking=True)
            teacher_value = teacher_value.to(device, non_blocking=True)

            B = pixels.size(0)
            # Initialize the thought vector.  Modify dimension to match your model's expectation.
            thought = torch.zeros(B, 32, device=device)

            student_out = student(pixels, scalars, goals, thought, step=global_step)
            loss = distillation_loss(student_out, teacher_logits, teacher_value)

            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(student.parameters(), max_norm=1.0)
            optimizer.step()

            if global_step % log_every == 0:
                with torch.no_grad():
                    action_acc = (
                        student_out.action_logits.argmax(-1) == teacher_logits.argmax(-1)
                    ).float().mean()
                    value_mse = nn.functional.mse_loss(student_out.value, teacher_value)
                    probs = nn.functional.softmax(student_out.action_logits, dim=-1)
                    policy_entropy = (
                        -torch.sum(probs * torch.log(probs + 1e-8), dim=-1).mean()
                    )
                print(
                    f"[epoch {epoch:02d} step {global_step:07d}] "
                    f"loss={loss.item():.4f} "
                    f"acc={action_acc.item():.4f} "
                    f"value_mse={value_mse.item():.4f} "
                    f"entropy={policy_entropy.item():.4f}"
                )

            global_step += 1

        # Validation and checkpointing at the end of each epoch
        if epoch % ckpt_every == 0:
            student.eval()
            val_loss = 0.0
            val_steps = 0
            with torch.no_grad():
                for batch in val_loader:
                    pixels, scalars, goals, teacher_logits, teacher_value = batch
                    pixels = pixels.to(device)
                    scalars = scalars.to(device)
                    goals = goals.to(device)
                    teacher_logits = teacher_logits.to(device)
                    teacher_value = teacher_value.to(device)
                    B = pixels.size(0)
                    thought = torch.zeros(B, 32, device=device)
                    out = student(pixels, scalars, goals, thought, step=0)
                    v_loss = distillation_loss(out, teacher_logits, teacher_value)
                    val_loss += v_loss.item()
                    val_steps += 1
            val_loss /= max(1, val_steps)
            ckpt_path = out_dir_path / f"student_epoch_{epoch}.pt"
            torch.save(student.state_dict(), ckpt_path)
            print(
                f"[epoch {epoch:02d}] Validation loss = {val_loss:.4f}; Saved checkpoint to {ckpt_path}"
            )

    # Save final model
    final_path = out_dir_path / "student_final.pt"
    torch.save(student.state_dict(), final_path)
    print(f"Training complete; final model saved to {final_path}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Train student model from VPT dataset")
    parser.add_argument("--dataset_path", type=str, required=True, help="Path to offline dataset file")
    parser.add_argument("--out_dir", type=str, required=True, help="Directory to save checkpoints")
    parser.add_argument("--batch_size", type=int, default=64, help="Batch size")
    parser.add_argument("--epochs", type=int, default=10, help="Number of training epochs")
    parser.add_argument("--lr", type=float, default=1e-4, help="Learning rate")
    parser.add_argument("--weight_decay", type=float, default=1e-5, help="Weight decay")
    parser.add_argument("--log_every", type=int, default=100, help="Steps between logging metrics")
    parser.add_argument("--ckpt_every", type=int, default=1, help="Epochs between saving checkpoints")
    args = parser.parse_args()

    train_student(
        dataset_path=args.dataset_path,
        out_dir=args.out_dir,
        batch_size=args.batch_size,
        epochs=args.epochs,
        lr=args.lr,
        weight_decay=args.weight_decay,
        log_every=args.log_every,
        ckpt_every=args.ckpt_every,
    )


if __name__ == "__main__":
    main()