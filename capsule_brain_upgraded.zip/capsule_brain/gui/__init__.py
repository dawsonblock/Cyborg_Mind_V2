"""Graphical user interface for the Capsule Brain."""
