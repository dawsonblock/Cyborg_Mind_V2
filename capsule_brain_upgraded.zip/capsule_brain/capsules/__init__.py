"""Capsule processor network."""

from .capsule_network import CapsuleLayer, CapsuleProcessorNetwork  # noqa: F401
