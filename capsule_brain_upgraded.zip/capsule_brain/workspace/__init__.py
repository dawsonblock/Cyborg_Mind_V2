"""Global workspace implementations."""

from .global_workspace import GlobalWorkspaceEngine  # noqa: F401
