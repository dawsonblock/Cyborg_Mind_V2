"""Teacher modules for Minecraft skill."""

from .clip_teacher import RealTeacher  # noqa: F401
