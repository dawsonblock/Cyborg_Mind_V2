"""Minecraft skill package."""
