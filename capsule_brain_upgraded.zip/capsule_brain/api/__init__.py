"""Capsule Brain API package."""
